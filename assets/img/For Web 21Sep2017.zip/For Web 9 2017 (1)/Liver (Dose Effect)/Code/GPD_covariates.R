rm(list=ls())

ordered2binary<-function(y){
  # transforms ordered (multi-choice) variable into a set of binary variables
  temp<-sort(unique(y))
  N<-length(y)
  M<-length(temp)
  # Matrix which will contain binary variables
  b<-matrix(0,N,M)
  # Transform
  for (i in 1:N){
    for (j in 1:M){
      if (y[i]==temp[j]){
        b[i,j]=1
      }
    }
  }
  return(b)
}

gmereglin.obj<-function(lambda,y,x,z,v){
  # INPUTS:
  #    lambda - lagrange multipliers of the dual (nx1 vector)
  #    y  - dependent variable (nx1 vector)
  #    x  - independent variables (nxk matrix)
  #    z  - support for beta coefs (kxm matrix)
  #    v  - support for error terms (mx1 vector det'd by the 3-sigma rule)
  # OUTPUT:
  #    ll - concentrated likelihood (dual)
  # Dimensions
  dimX<-dim(x)
  n<-dimX[1]   # Number of observations
  k<-dimX[2]   # Number of regressor (incl. constant)
  M<-dim(z)[2]
  # Partition function (Phi)
  Phi<-matrix(0,k,1)
  for (j in 1:k) {
    for (m in 1:M) {
      Phi[j,1]<-Phi[j,1]+exp(-z[j,m]*sum(lambda*x[,j]))
    }
  }
  # Partition function (Psi)
  Psi<-matrix(0,n,1)
  for (i in 1:n){
    Psi[i,1]<-sum(exp(-lambda[i]*v))
  }
  # Dual (Concentrated log-likelihood)
  ll<-sum(y*lambda)+sum(log(Phi))+sum(log(Psi))
  # Return value
  return(ll)
}

gmereglin.Gr<-function(lambda,y,x,z,v){
  # INPUTS:
  #    lambda - lagrange multipliers of the dual (nx1 vector)
  #    y  - dependent variable (nx1 vector)
  #    x  - independent variables (nxk matrix)
  #    z  - support for beta coefs (kxm matrix)
  #    v  - support for error terms (mx1 vector det'd by the 3-sigma rule)
  # OUTPUT:
  #    ll - concentrated likelihood (dual)
  # Dimensions
  dimX<-dim(x)
  n<-dimX[1]   # Number of observations
  K<-dimX[2]   # Number of regressor (incl. constant)
  M<-dim(z)[2]
  # Partition function (Phi)
  Phi<-matrix(0,K,1)
  for (k in 1:K) {
    for (m in 1:M) {
      Phi[k,1]<-Phi[k,1]+exp(-z[k,m]*sum(lambda*x[,k]))
    }
  }
  # Partition function (Psi)
  Psi<-matrix(0,n,1)
  for (i in 1:n){
    Psi[i,1]<-sum(exp(-lambda[i]*v))
  }
  # First-order derivative of Partition function (Phi)
  grad<-matrix(0,n,1)
  Phi1<-matrix(0,K,1)
  Psi1<-matrix(0,n,1)
  for (i in 1:n) {
    temp<-0
    for (k in 1:K) {
      for (m in 1:M) {
        Phi1[k,1]<-Phi1[k,1]+z[k,m]*exp(-z[k,m]*sum(lambda*x[,k]))
      }
      temp<-temp-x[i,k]*Phi1[k,1]/Phi[k,1]
    }
    Psi1[i,1]<- -sum(v*exp(-lambda[i]*v))
    grad[i,1]<- y[i]+temp+Psi1[i,1]/Psi[i,1] 
  }
  # Return value
  return(grad)
}

gmereglin.est<-function(y,x,z,optim_Method) {
  # Dimensions
  dimX<-dim(x)
  n<-dimX[1]   # Number of observations
  k<-dimX[2]   # Number of regressor (incl. constant)
  M<-dim(z)[2]
  # Error support by the 3 sigma rule
  sdY<-sd(y)
  v=matrix(0,3,1)
  v[1,1]<- -3*sdY
  v[3,1]<-  3*sdY
  # Initial values of lagrange multipliers
  lambda0<-matrix(0.0001,n,1)
  # Optimization
  gme.est<-optim(lambda0,gmereglin.obj,gmereglin.Gr,y=y,x=x,z=z,v=v,method=optim_Method)
  # Lagrange multipliers
  lambda.hat<-gme.est$par
  # Est'd prob's for the beta coefficients
  p.hat<-matrix(0,k,M)
  for (j in 1:k) {
    for (m in 1:M) {
      p.hat[j,m]<-exp(-z[j,m]*sum(lambda.hat*x[,j]))
    }
    p.hat[j,]<-p.hat[j,]/sum(p.hat[j,])
  }
  # Beta coef's
  beta.hat<-matrix(0,k,1)
  for (j in 1:k) {
    beta.hat[j,1]<-sum(z[j,]*p.hat[j,])
  }
  # Est'd prob's for the noise 
  w.hat<-matrix(0,n,3)
  for (i in 1:n) {
    for (m in 1:3) {
      w.hat[i,m]<-exp(-lambda.hat[i,1]*v[m,1])
    }
    w.hat[i,]<-w.hat[i,]/sum(w.hat[i,])
  }
  # Error terms
  e.hat<-matrix(0,n,1)
  for (i in 1:n) {
    e.hat[i,1]<-w.hat[i,]%*%v[,1]
  }
  # return value
  newList<-list("lambda"=lambda.hat,"beta"=beta.hat,"p"=p.hat,"w"=w.hat,"e"=e.hat,"conv"=gme.est$conv)
  return(newList)
}

library(texmex)
library(MASS)
library(lattice)

palette(c("black","purple","gray85","black"))
set.seed(20111011)

data(liver)
head(liver)

liver<-liver
liver$ndose<-as.numeric(liver$dose)
table(liver$ndose)

# Deleting non-sensical observations
liver<-liver[liver$ALP.M>1,]

# Add dummies to data
bin.dose<-ordered2binary(liver$ndose)
liver$dose1<-NULL
liver$dose1<-bin.dose[,1]
liver$dose2<-NULL
liver$dose2<-bin.dose[,2]
liver$dose3<-NULL
liver$dose3<-bin.dose[,3]
liver$dose4<-NULL
liver$dose4<-bin.dose[,4]

# OLS regression (dose as continuous variable)
ols1.reg<-lm(log(ALT.M)~log(ALT.B)+ndose,data=liver)
summary(ols1.reg)

# OLS regression (dose as discrete variable)
ols2.reg<-lm(log(ALT.M)~log(ALT.B)+dose2+dose3+dose4,data=liver)
summary(ols2.reg)

# Robust regression (dose as continuous variable)
rmod1<-rlm(log(ALT.M)~log(ALT.B)+ndose,data=liver,c=3.44,method="MM")
summary(rmod1)

# Robust regression (dose as discrete variable)
rmod2<-rlm(log(ALT.M)~log(ALT.B)+dose2+dose3+dose4,data=liver,c=3.44,method="MM")
summary(rmod2)

# Graphical analysis
print(xyplot(ALT.M~ALT.B|dose,data=liver,as.table=TRUE,scales=list(log=2)))
par(mfrow=c(2,2))
plot(fitted(rmod),resid(rmod),xlab="Fitted",ylab="Residuals")
abline(h=0,col=2)
qqnorm(resid(rmod))
qqline(resid(rmod))
plot(log(liver$ALT.M),fitted(rmod),xlab="Observed",ylab="Fitted")
d<-density(resid(rmod))
hist(resid(rmod),xlab="Residuals",prob=T,ylim=range(d$y))
lines(d)
rug(resid(rmod))

# Analysis of residuals
liver$r<-resid(rmod)
par(mfrow=c(1,1))
plot(jitter(liver$ndose),liver$r,main="Robust Reg",xlab="Dose",ylab="Scaled Residuals",axes=F)
box();axis(2)
axis(1,at=1:4,labels=LETTERS[1:4])
abline(h=c(-1,0,1),lty=c(2,1,2),lwd=c(2,2,2),col=c(3,4,3))

# GME estimates
n<-length(liver$ALT.B)
z<-matrix(0,3,3)
z[,1]<- -2.24; z[,3]<- 2.24
zz<-cbind(log(liver$ALT.M),matrix(1,n,1),log(liver$ALT.B),liver$ndose)
yy<-zz[,1]
xx<-zz[,2:4]
gme.est<-gmereglin.est(zz[,1],zz[,2:4],z,"BFGS")
gme.est$conv
gme.est$beta
yhat.gme<-xx%*%gme.est$beta
gme.r<-zz[,1]-yhat.gme

n<-length(liver$ALT.B)
z<-matrix(0,5,3)
z[,1]<- -2.2; z[,3]<- 2.2
zz<-cbind(log(liver$ALT.M),matrix(1,n,1),log(liver$ALT.B),liver$dose2,liver$dose3,liver$dose4)
# zz<-cbind(log(liver$ALT.M),log(liver$ALT.B),liver$dose1,liver$dose2,liver$dose3,liver$dose4)
yy<-zz[,1]
xx<-zz[,2:6]
gme1.est<-gmereglin.est(zz[,1],xx,z,"BFGS")
gme1.est$conv
gme1.est$beta
yhat.gme1<-xx%*%gme1.est$beta
gme1.r<-zz[,1]-yhat.gme1

# Variance covariance matrix
s2<-t(gme1.r)%*%gme1.r/(n-ncol(xx))
invXTX<-solve(t(xx)%*%xx)
se<-sqrt(s2*diag(invXTX))
gme.coefs<-cbind(gme1.est$beta,se,gme1.est$beta/se)
colnames(gme.coefs)<-c("COEFS","SE","T-STAT")
round(gme.coefs,4)

# Residuals from GME estimator
liver$r<-NULL
liver$r<-gme1.r

# Analysis of residuals
par(mfrow=c(3,1),cex.axis=2,cex.lab=2)
plot(jitter(liver$ndose),resid(rmod2),pch=19,xlab="Dose",ylab="Residuals",font.axis=4,axes=F)
box();axis(2)
axis(1,at=1:4,labels=LETTERS[1:4])
abline(h=c(-1,0,1),lty=c(2,1,2),lwd=c(3,3,3),col=c(3,4,3))
plot(jitter(liver$ndose),gme.r,pch=19,xlab="Dose",ylab="Residuals",axes=F)
box();axis(2)
axis(1,at=1:4,labels=LETTERS[1:4])
abline(h=c(-1,0,1),lty=c(2,1,2),lwd=c(3,3,3),col=c(3,4,3))
plot(jitter(liver$ndose),gme1.r,pch=19,xlab="Dose",ylab="Residuals",axes=F)
box();axis(2)
axis(1,at=1:4,labels=LETTERS[1:4])
abline(h=c(-1,0,1),lty=c(2,1,2),lwd=c(3,3,3),col=c(3,4,3))

# Analysis of residuals (OLS, Robust, GME)
par(mfrow=c(1,3))
plot(fitted(ols.reg),resid(ols.reg),main="OLS",xlab="Fitted",ylab="Residuals",ylim=c(-2,3.5))
abline(h=0,col=2)
plot(fitted(rmod),resid(rmod),main="Robust Regression",xlab="Fitted",ylab="Residuals",ylim=c(-2,3.5))
abline(h=0,col=2)
plot(yhat.gme,gme.r,main="GME regression",xlab="Fitted",ylab="Residuals",ylim=c(-2,3.5))
abline(h=0,col=2)

#**********************************
#**** GENERALIZED PARETO MODEL ****
#**********************************

# Preliminary analysis
par(mfrow=c(1,2))
plot(gpdRangeFit(liver$r))
par(mfrow=c(1,1))
plot(mrl(liver$r),main="MRL plot")

# Quantiles
quantile(liver$r,0.5)
q07<-quantile(liver$r,0.7)

# Fitting GPD model
pp<-list(c(0,0),diag(c(10^4,0.25)))
pmod0<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none")
pmod0
pmod<-evm(r,data=liver,qu=0.7,family=gpd,penalty="gaussian",priorParameters=pp)
pmod
par(mfrow=c(2,2))
plot(pmod)

# Parameters by each dose
sub1<-subset(liver,liver$ndose==1)
sub2<-subset(liver,liver$ndose==2)
sub3<-subset(liver,liver$ndose==3)
sub4<-subset(liver,liver$ndose==4)
model1<-evm(r,data=sub1,qu=0.7,family=gpd,penalty="none")
summary(model1)
model2<-evm(r,data=sub2,qu=0.7,family=gpd,penalty="none")
summary(model2)
model3<-evm(r,data=sub3,qu=0.7,family=gpd,penalty="none")
summary(model3)
model4<-evm(r,data=sub4,qu=0.7,family=gpd,penalty="none")
summary(model4)

# Model selection
mod1<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",phi=~dose,xi=~dose)
mod2<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",phi=~ndose,xi=~ndose)
mod3<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",phi=~ndose)
mod4<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",xi=~ndose)
mod5<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",xi=~dose1+dose2+dose3+dose4-1)
mod6<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",phi=~dose1+dose2+dose3+dose4-1)
mod7<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",xi=~dose1+dose2+dose3+dose4-1,phi=~dose1+dose2+dose3+dose4-1)
mod8<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",xi=~dose2+dose3+dose4)
mod9<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",phi=~dose2+dose3+dose4)
mod10<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",xi=~dose2+dose3+dose4,phi=~dose2+dose3+dose4)
mod11<-evm(r,data=liver,qu=0.7,family=gpd,penalty="none",phi=~dose2+dose3+dose4+I(dose4*AST.B))

c(AIC(mod1),AIC(mod2),AIC(mod3),AIC(mod4),AIC(mod5),AIC(mod6),AIC(mod7))

palette(c("black","purple","gray80","black"))

# Closer look at the chosen model
summary(mod4)
par(mfrow=c(2,2),pty="s")
plot(mod4)
plot(predict(mod4,type="lp",ci.fit=T),main="Fitted shape parameter")
par(mfrow=c(2,2),pty="m",cex.axis=2,cex.lab=2,lwd=2)
plot(predict(mod4,M=10:100,ci.fit=T))

zz<-predict(mod4,M=10:100,ci.fit=T)
for (i in 1:91) {
  if (i==1) {
    temp.all<-as.matrix(zz[[i]])
  } else {
    temp<-as.matrix(zz[[i]])
    temp.all<-rbind(temp.all,temp)
  }
}
ttt<-data.frame(temp.all)
colnames(ttt)<-c("RL","Lo","Up","ndose")
ttt1<-subset(ttt,ttt$ndose==1)
ttt2<-subset(ttt,ttt$ndose==2)
ttt3<-subset(ttt,ttt$ndose==3)
ttt4<-subset(ttt,ttt$ndose==4)

xx<-seq(10,100,length=91)

par(mfrow=c(2,2),mai=c(1.02,0.65,0.65,0.42),pty="m")

plot(xx,ttt1$RL,type="l",lwd=3,ylab="",xlab="",ylim=c(0.3,2.3))
lines(xx,ttt1$Lo,lwd=3,lty=3)
lines(xx,ttt1$Up,lwd=3,lty=3)

plot(xx,ttt2$RL,type="l",lwd=3,ylab="",xlab="",ylim=c(0.3,2.3))
lines(xx,ttt2$Lo,lwd=3,lty=3)
lines(xx,ttt2$Up,lwd=3,lty=3)

plot(xx,ttt3$RL,type="l",lwd=3,ylab="",xlab="",ylim=c(0.3,2.3))
lines(xx,ttt3$Lo,lwd=3,lty=3)
lines(xx,ttt3$Up,lwd=3,lty=3)

plot(xx,ttt4$RL,type="l",lwd=3,ylab="",xlab="",ylim=c(0.3,2.3))
lines(xx,ttt4$Lo,lwd=3,lty=3)
lines(xx,ttt4$Up,lwd=3,lty=3)

summary(mod5)$coefficients
summary(mod4)$model
rbind(mod4$loglik,
mod5$loglik,
mod6$loglik,
mod7$loglik,
mod8$loglik,
mod9$loglik,
mod10$loglik)

rbind(AIC(mod4),
      AIC(mod5),
      AIC(mod6),
      AIC(mod7),
      AIC(mod8),
      AIC(mod9),
      AIC(mod10))

plot(liver$r,fitted(mod4))

################################
##### SENSITIVITY ANALYSIS #####
################################
n<-length(liver$ALT.B)
z<-matrix(0,5,3)
zz<-cbind(log(liver$ALT.M),matrix(1,n,1),log(liver$ALT.B),liver$dose2,liver$dose3,liver$dose4)
yy<-zz[,1]
xx<-zz[,2:6]
step_size<-0.02
ss<-seq(1,3,by=0.02)
bs<-length(ss)
gme.all<-matrix(0,bs,5)
gme_conv_all<-matrix(0,bs,1)
for (i in 1:bs){
  z[,1]<- -1-i*0.02; z[,3]<- 1+i*0.02
  gme.bs<-gmereglin.est(yy,xx,z,"BFGS")
  gme_conv_all[i,1]<-gme.bs$conv
  gme.all[i,]<-gme.bs$beta
  print(paste("iter=",i," conv=",gme.bs$conv))
}

tembrr<-cbind(ss,gme.all,gme_conv_all)
write.csv(tembrr,"c:/Data/AmosBook/MedicalExample/gme_all_Jan30.csv")

# Export return levels
zzz<-as.matrix(predict(mod4,M=10:100,ci.fit=T))
write.csv(zzz,"c:/Data/AmosBook/MedicalExample/return_levels_Jan31.csv")




























gme.return<-predict(mod4,M=10:100,ci.fit=T)
tempr<-data.matrix(gme.return)
write.csv(tempr,"c:/Data/AmosBook/medics3.csv")

rob.return<-predict(mod4,M=10:100,ci.fit=T)
temprob<-data.matrix(rob.return)
write.csv(temprob,"c:/Data/AmosBook/medics1.csv")

par(mfrow=c(2,2))
plot(subset(liver,liver$ndose==1)[,1],subset(liver,liver$ndose==1)[,5],main="ALP")
plot(subset(liver,liver$ndose==1)[,2],subset(liver,liver$ndose==1)[,6],main="ALT")
plot(subset(liver,liver$ndose==1)[,3],subset(liver,liver$ndose==1)[,7],main="AST")
plot(subset(liver,liver$ndose==1)[,4],subset(liver,liver$ndose==1)[,8],main="TBL")

par(mfrow=c(2,4))
plot(subset(liver,liver$ndose==1)[,1],subset(liver,liver$ndose==1)[,5],main="ALP")
plot(subset(liver,liver$ndose==1)[,2],subset(liver,liver$ndose==1)[,6],main="ALT")
plot(subset(liver,liver$ndose==1)[,3],subset(liver,liver$ndose==1)[,7],main="AST")
plot(subset(liver,liver$ndose==1)[,4],subset(liver,liver$ndose==1)[,8],main="TBL")
plot(subset(liver,liver$ndose==4)[,1],subset(liver,liver$ndose==4)[,5],main="ALP")
plot(subset(liver,liver$ndose==4)[,2],subset(liver,liver$ndose==4)[,6],main="ALT")
plot(subset(liver,liver$ndose==4)[,3],subset(liver,liver$ndose==4)[,7],main="AST")
plot(subset(liver,liver$ndose==4)[,4],subset(liver,liver$ndose==4)[,8],main="TBL")

par(mfrow=c(2,2))
hist(subset(liver,liver$ndose==1)[,6])
hist(subset(liver,liver$ndose==2)[,6])
hist(subset(liver,liver$ndose==3)[,6])
hist(subset(liver,liver$ndose==4)[,6])

z1<-length(subset(liver,liver$ndose==1)[,6])
z2<-length(subset(liver,liver$ndose==2)[,6])
z3<-length(subset(liver,liver$ndose==3)[,6])
z4<-length(subset(liver,liver$ndose==4)[,6])
c(z1,z2,z3,z4)

dALT<-liver$ALT.M-liver$ALT.B
dd<-log(liver$ALT.M)-log(liver$ALT.B)
par(mfrow=c(1,1))
hist(dALT)
summary(dALT)

par(mfrow=c(1,1))
hist(dd)
summary(dd)
sd.dd<-sd(dd)
length(dd[dd>-sd.dd & dd<sd.dd])
length(dd[dd>-2*sd.dd & dd<2*sd.dd])

n<-length(liver$ALT.M)
d.i<-matrix(0,n,1)
for (i in 1:n){
  if (abs(dd[i])<=sd.dd) {
    d.i[i,1]<-1
  } else if (abs(dd[i])>sd.dd & abs(dd[i])<=2*sd.dd) {
    d.i[i,1]<-2
  } else if (abs(dd[i])>2*sd.dd) {
    d.i[i,1]<-3
  } 
}
head(cbind(d.i,dd,liver$ALT.M,liver$ALT.B))

unique(d.i)
length(d.i[d.i==1])
length(d.i[d.i==2])
length(d.i[d.i==3])
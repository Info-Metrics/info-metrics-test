
SUBJECT:    Generalized Maximum Entropy Estimation of Multinomial Discrete Choice Models

AUTHOR(S):  Paul Corral
            American University, Washington, DC

SUPPORT:    <paul.corral@gmail.com>

 

FILES:

1) Run gmemultinomial.ado
2) save gmemultinomial.ado in c:\ado\plus\g\
...
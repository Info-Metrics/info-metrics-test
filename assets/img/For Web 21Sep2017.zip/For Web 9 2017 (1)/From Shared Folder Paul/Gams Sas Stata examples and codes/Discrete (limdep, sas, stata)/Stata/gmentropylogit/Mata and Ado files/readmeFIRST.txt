How to install GMElogit:

1) Make sure you have the following folders:

 c:\ado\plus\g\


2) run "gmentropylogit.ado"

3) copy "gmentropylogit.ado" and "gmentropylogit.sthlp" files to: 

c:\ado\plus\g\




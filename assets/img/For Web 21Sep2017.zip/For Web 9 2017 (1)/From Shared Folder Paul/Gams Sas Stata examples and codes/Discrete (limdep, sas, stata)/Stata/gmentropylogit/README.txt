------------------------------------------------------------------------------

SUBJECT:    Generalized Maximum Entropy Estimation of Discrete Choice Models

AUTHOR(S):  Paul Corral
            American University, Washington, DC

            Mungo Terbish
            American University, Washington, DC

            ...

SUPPORT:    <paul.corral@gmail.com>

HELP:       After installation, type


            . help gmentropylogit
           

FILES:

gmentropylogit.ado
gmentropylogit.sthlp
GME mata code MFX.do
GME mata code.do
optimizing function.do
predict_gme mata.do
...
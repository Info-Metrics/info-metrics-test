
SUBJECT:    Generalized Maximum Entropy Estimation of Multinomial Discrete Choice Models

AUTHOR(S):  Paul Corral
            American University, Washington, DC

SUPPORT:    <paul.corral@gmail.com>

 

FILES:

run "opti multi.do"
run "multidis mata.do"
run "gmeMlogit.do
...
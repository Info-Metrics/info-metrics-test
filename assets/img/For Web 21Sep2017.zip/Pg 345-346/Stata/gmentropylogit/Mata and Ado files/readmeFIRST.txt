How to install GMElogit:

1) Make sure you have the following folders:

 c:\ado\personal\

 c:\ado\plus\g\


2) run "optimizing function.do"
3) run "GME mata code.do"
4) run "GME mata code MFX.do"
5) run "predict_gme mata.do"

6) run "gmentropylogit.ado"

3) copy "gmentropylogit.ado" and "gmentropylogit.sthlp" files to: 

c:\ado\plus\g\




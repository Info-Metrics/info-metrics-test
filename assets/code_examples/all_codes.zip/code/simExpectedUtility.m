function psi = simExpectedUtility(Data,lambda)

[T nAsset] = size(Data);

AssetReturns = mean(Data)';
AssetCov = cov(Data);

%%
nSim = 500;
psi = zeros(nSim,1);

parfor i = 1:nSim
    SimRets = mvnrnd(AssetReturns,AssetCov,T);
    mu{i} = mean(SimRets)';
    Sigma{i}= cov(SimRets);

    
    H = Sigma{i}.*lambda./2;
    
    Aeq = ones(1,nAsset);
    beq = 1;
    
    f = -mu{i}';  
    
    lb = zeros(nAsset,1);
    ub = ones(nAsset,1);
    x0 = ones(nAsset,1).*1/nAsset;
    options = optimoptions('quadprog',...
        'Algorithm','interior-point-convex','Display','off');
    [x,fval,exitflag,output,~] = quadprog(H,f,[],[],Aeq,beq,lb,ub,x0,options);
    
    simWgt{i} = x';
    simR(i) = x'*mu{i};
    simSig(i) = x'*Sigma{i}*x;
    psi(i) = x'*mu{i} - lambda.*x'*Sigma{i}*x./2;
    
    
end


end
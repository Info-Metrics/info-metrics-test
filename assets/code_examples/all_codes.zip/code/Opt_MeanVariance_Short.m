% this program solves for optimal portfolio at given risk aversion 

function [ret sig wgt] =  Opt_MeanVariance_Short(Data, lambda)

% Data: TxN
% lambda: risk aversion
[T N] = size(Data);

AssetReturns = mean(Data)';
AssetCov = cov(Data);
nAsset = N;
H = AssetCov.*lambda;

Aeq = ones(1,nAsset);
beq = 1;

f = -AssetReturns';

lb = -ones(nAsset,1);
ub = ones(nAsset,1);
x0 = ones(nAsset,1).*1/nAsset;
options = optimoptions('quadprog',...
    'Algorithm','interior-point-convex','Display','off');
[x,fval,exitflag,output,~] = quadprog(H,f,[],[],Aeq,beq,lb,ub,x0,options);

ret = x'*AssetReturns;
sig = sqrt(x'*AssetCov*x);
wgt = x;
end




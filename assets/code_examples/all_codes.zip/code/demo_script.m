clc
clear

[A B] = importdata('10_Industry_Portfolios.csv');

Date = A.data(:,1);
Data = A.data(:,end-2:end); % pick 3 industry

%%
startindex = find(200001 == Date);
endindex = find(200501 == Date);

Date = Date(startindex:endindex,:);
Data = Data(startindex:endindex,:);


AssetReturns = mean(Data)';
AssetCov = cov(Data);
AssetVar = diag(AssetCov);
AssetCorr = corrcoef(Data);
nAsset = length(AssetReturns);



%%
[ret_mv,sig_mv, wgt_mv] = EfficientFrontier_MV(100, AssetCov, AssetReturns);
% min variance portfolio weight 
minVarWgt = wgt_mv(1,:)'
[ret_me,sig_me, wgt_me] = EfficientFrontier_ME(100, AssetCov, AssetReturns);
[ret_me2,sig_me2, wgt_me2] = EfficientFrontier_ME_withVol(100, AssetCov, AssetReturns);


plot(sig_mv,ret_mv,':',sig_me,ret_me,sig_me2,ret_me2,'--')
legend('mean-variance','ME (no vol as input)','ME (with vol)','Location','southoutside')
title('efficient frontier')
%%
% prior weight = min variance
plotEntropyContour(Data,minVarWgt)
title({'contour curves of entropy,',' q = min variance portfolio weights'})

%%
lambda = 0.06; % risk-aversion coefficient. 

% optMV : mean-variance solution
[optMV_ret optMV_sig optMV_wgt]=Opt_MeanVariance(Data,lambda);
optMV_util = optMV_wgt'*mean(Data)' - 0.06*optMV_wgt'*cov(Data)*optMV_wgt/2

%%
psi = simExpectedUtility(Data,lambda);
[f,xi] = ksdensity(psi); % pdf
plot(xi,f)
title({'non-parametric density for expected utility',' (from re-sampling)'})
xlabel('expected utility')
ylabel('density')

%%
% alpha the percentile (confidence level)
alpha = 0.4;
[F,Xi] = ksdensity(psi,'function','cdf'); %cdf
[~, index]=find(F<=alpha);% percentile
psi_alpha = Xi(index(end))  % expected utility at 30-th percentile 
f_alpha = f(xi==psi_alpha);
hold on
plot([psi_alpha psi_alpha],[0 f_alpha])
text(psi_alpha, f_alpha/2, '40-th percentile', 'fontweight', 'bold')
hold off

%%
% optCE cross-entropy solution (q = 1/n)
[optCE_ret optCE_sig optCE_wgt]=Opt_CrossEntropy(Data,lambda,psi_alpha);
optCE_util = optCE_wgt'*mean(Data)' - 0.06*optCE_wgt'*cov(Data)*optCE_wgt/2

%%
% equal weights portfolio, the prior weight (q = 1/n)
pi = ones(nAsset,1)/nAsset;
eq_sig = sqrt(pi'*AssetCov*pi);
eq_ret = pi'*AssetReturns;

% Utility Curve
% U = R - lamba * V^2/2
for i = 1:length(ret_mv)
    mvSig(i) = sqrt(2*(ret_mv(i) - optMV_util)/lambda);
end

plot(sig_mv,ret_mv)
hold on
plot(mvSig,ret_mv)
h1=plot(optMV_sig,optMV_ret,'*');
h2=plot(eq_sig,eq_ret,'*');
h3=plot(optCE_sig,optCE_ret,'+');
xlabel('Standard Dev')
ylabel('Expected Return')
legend([h1 h2 h3 ],{'MV','prior (1/n)','CE (40%)'},'Location','southoutside','Orientation','horizontal')
xlim([min(sig_mv) max(sig_mv)])
title('Shrinkage effect of minimizing cross-entropy')
hold off
 

%%
[nDates, ~]= size(Data);

T = nDates;
W = 24; % 24-months rolling window
alpha = 0.4; % given confidence level (percentile of Exepcted utility)

for i = W:T-1
    tmp = Data(i-W+1:i,:);  % in-sample data:[i-W+1:i]
    tmpRet = mean(tmp)';
    tmpSig = cov(tmp);
    psi = simExpectedUtility(tmp,lambda);
    [F,Xi] = ksdensity(psi,'function','cdf'); %cdf
    [~, index]=find(F<=alpha);% percentile
    psi_alpha = Xi(index(end)); % expected utility at alpha-th percentile
    [optCE_ret, optCE_sig, optCE_wgt]=Opt_CrossEntropy(tmp,lambda,psi_alpha);
    [optMV_ret, optMV_sig, optMV_wgt]=Opt_MeanVariance(tmp,lambda);
    
    % in-sample
    optCE_wgt_all(:,i-W+1)=optCE_wgt;
    optMV_wgt_all(:,i-W+1)=optMV_wgt; 

    SR_in.CE(i-W+1) =  (optCE_wgt'*tmpRet)/sqrt(optCE_wgt'*tmpSig*optCE_wgt); % Sharpe Ratio
    SR_in.MV(i-W+1) =  (optMV_wgt'*tmpRet)/sqrt(optMV_wgt'*tmpSig*optMV_wgt); % Sharpe Ratio
    
    %out-sample
    mu_t.CE(i-W+1) = optCE_wgt'*Data(i+1,:)';
    mu_t.MV(i-W+1) = optMV_wgt'*Data(i+1,:)';
    
end

SR_in.CE = mean(SR_in.CE);
SR_in.MV = mean(SR_in.MV);
SR_in

SR_out.CE = mean(mu_t.CE)/std(mu_t.CE);
SR_out.MV = mean(mu_t.MV)/std(mu_t.MV);
SR_out


plot(optMV_wgt_all(1,:),':')
hold on
plot(optCE_wgt_all(1,:))
hold off
title('Health Sector Weight')
legend({'MV','CE'},'Location','southoutside','Orientation','horizontal')



%% MV with short

[optMV_short_ret optMV_short_sig optMV_short_wgt]=Opt_MeanVariance_Short(Data,lambda);

% CE with short
[optCE_short_ret optCE_short_sig optCE_short_wgt]=Opt_CrossEntropy_Short(Data,lambda,psi_alpha);


%% with short
[nDates nAsset]= size(Data);

T = nDates;
W = 24; % 24-months rolling window
alpha = 0.4; % given confidence level (percentile of Exepcted utility)

for i = W:T-1
    tmp = Data(i-W+1:i,:);
    tmpRet = mean(tmp)';
    tmpSig = cov(tmp);
    psi = simExpectedUtility_Short(tmp,lambda);
    [F,Xi] = ksdensity(psi,'function','cdf'); %cdf
    [~, index]=find(F<=alpha);% percentile
    psi_alpha = Xi(index(end)); % expected utility at alpha-th percentile
    [optCE_short_ret, optCE_short_sig, optCE_short_wgt]=Opt_CrossEntropy_Short(tmp,lambda,psi_alpha);
    [optMV_short_ret, optMV_short_sig, optMV_short_wgt]=Opt_MeanVariance_Short(tmp,lambda);
    
    optCE_short_wgt_all(:,i-W+1)=optCE_short_wgt;
    optMV_short_wgt_all(:,i-W+1)=optMV_short_wgt;
    
    %in-sample

    SR_in.CE_short(i-W+1) =  (optCE_short_wgt'*tmpRet)/sqrt(optCE_short_wgt'*tmpSig*optCE_short_wgt); % Sharpe Ratio
    SR_in.MV_short(i-W+1) =  (optMV_short_wgt'*tmpRet)/sqrt(optMV_short_wgt'*tmpSig*optMV_short_wgt); % Sharpe Ratio
    
    %out-sample
    mu_t.CE_short(i-W+1) = optCE_short_wgt'*Data(i+1,:)';
    mu_t.MV_short(i-W+1) = optMV_short_wgt'*Data(i+1,:)';    
end

SR_in.CE_short = mean(SR_in.CE_short);
SR_in.MV_short = mean(SR_in.MV_short);
SR_in

SR_out.CE_short = mean(mu_t.CE_short)/std(mu_t.CE_short);
SR_out.MV_short = mean(mu_t.MV_short)/std(mu_t.MV_short);
SR_out

plot(optMV_short_wgt_all(1,:),':')
hold on
plot(optCE_short_wgt_all(1,:))
hold off
title('Health Sector Weight (with short)')
legend({'MV (with short)','CE(with short)'},'Location','southoutside','Orientation','horizontal')
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
function [ret sig wgt] =  Opt_CrossEntropy(Data,lambda,psi,varargin)
% Data: TxN
% lambda: risk aversion
% confidence: percentage

[T N] = size(Data);

AssetReturns = mean(Data)';
AssetCov = cov(Data);
nAsset = N;

if isempty(varargin)
    q = ones(nAsset,1)/nAsset;
else
    q = varargin{:};
end



%%

fun = @(p) sum(p.*log(p./q));
x0 = ones(nAsset,1)/nAsset;
Aeq = ones(1,nAsset);
beq = 1;


mycon=@(wgt) deal(-wgt'*AssetReturns + lambda.*wgt'*AssetCov*wgt./2 + psi,[]);

lb = zeros(nAsset,1);
ub = ones(nAsset,1);
options = optimoptions('fmincon','Display','none','Algorithm','sqp');

x = fmincon(fun,x0,[],[],Aeq,beq,lb,ub,mycon,options);

ret = x'*AssetReturns;
sig = sqrt(x'*AssetCov*x);
wgt = x;
end

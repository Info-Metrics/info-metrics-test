function plotEntropyContour(Data,varargin)
% Data is TxN
% N: # of assets
% T: time period

% plotEntropyContour(Data)              
% plotEntropyContour(Data,prior)  


AssetReturns = mean(Data)';
AssetCov = cov(Data);
nAsset = length(AssetReturns);

if isempty(varargin)
    defaultPrior = ones(nAsset,1)/nAsset;
    q = defaultPrior;
else
    q = varargin{:};
end
%%
minWgt = 0.01;
maxWgt = 1;
nPoints = 40;
wgtRange = (minWgt:(maxWgt-minWgt)/nPoints:maxWgt)';
wgtMat = permWeights(wgtRange,nAsset);
[nTrial , ~] = size(wgtMat);

portR = zeros(nTrial,1);
portV = zeros(nTrial,1);
portE = zeros(nTrial,1);

for i = 1:nTrial
    wgt = wgtMat(i,:)';
    portR(i) = wgt' * AssetReturns;
    portV(i) = sqrt(wgt' * AssetCov * wgt);
    portE(i) = - sum(wgt.*log(wgt./q));
end

quantE = quantile(portE, [0.025 0.25 0.5 0.75 0.975]);

% lowest quantile
ind = portE<=quantE(1);
scatter(portV(ind),portR(ind));

% quantiles in between
for i = 2:length(quantE)
    hold on 
    ind = ((portE<=quantE(i))& (portE>quantE(i-1)));
    scatter(portV(ind),portR(ind))
end

% highest quantile
ind = portE>quantE(end);
scatter(portV(ind),portR(ind));

hold off

legend({'0.25%','2.5%','50%','75%','97.5%','>97.5%'});

title('entropy contour')








function [ExpectedValue,Volatility, Composition] = EfficientFrontier_ME(NumPortf, Covariance, ExpectedValues)

% This function returns the NumPortf x 1 vector expected returns,
%                       the NumPortf x 1 vector of volatilities and
%                       the NumPortf x NumAssets matrix of compositions
% of NumPortf efficient portfolios whose expected returns are equally spaced along the whole range of the efficient frontier

NumAssets=size(Covariance,2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% determine return of maximum-return portfolio
[MaxRet_Return,MaxRet_Index]=max(ExpectedValues);
[MinRet_Return,MinRet_Index]=min(ExpectedValues);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% slice efficient frontier in NumPortf equally thick horizontal sectors in the upper branch only
Step=(MaxRet_Return-MinRet_Return)/(NumPortf-1);
TargetReturns=[MinRet_Return : Step : MaxRet_Return];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute the NumPortf compositions and risk-return coordinates of the optimal allocations relative to each slice

Composition=[];
Volatility=[];
ExpectedValue=[];
fun = @(x) sum(x.*log(x));

for i=1:NumPortf
    
    % determine least risky portfolio for given expected return
    AEq=[ones(1,NumAssets);
        ExpectedValues'];
    bEq=[1;
        TargetReturns(i)];
    options = optimoptions('fmincon','Display','none','Algorithm','sqp');
    lb = zeros(NumAssets,1);
    ub = ones(NumAssets,1);
    x0=1/NumAssets*ones(NumAssets,1);

    Weights = fmincon(fun,x0,[],[],AEq,bEq,lb,ub,[],options)';
    Composition=[Composition
        Weights];
    Volatility=[Volatility
        sqrt(Weights*Covariance*Weights')];
    ExpectedValue=[ExpectedValue
        Weights*ExpectedValues];
end


[minVol minVolInd]= min(Volatility);
minVolRet = ExpectedValue(minVolInd);
ind = (ExpectedValue>=minVolRet);
Composition = Composition(ind,:);
Volatility = Volatility(ind);
ExpectedValue = ExpectedValue(ind);
end

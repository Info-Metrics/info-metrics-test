x = 0.00001:0.01:0.99999;
[X,Y] = meshgrid(x);

H = -X.*log(X)- Y.*log(Y)-(1- X-Y).*log(1- X-Y);


R = real(H);%real part
I = imag(H);%imaginary part

    for i= 1:length(x)
        for k=1:length(x)  
            if X(i,k)+Y(i,k)>1
            R(i,k)=NaN;
            end
        end
    end

figure;hold on; grid on

    %For more thinner lines
    %[C,h]=contour3(X,Y,R,150);
    % set(h,'LineWidth',1);

    % For fewer thicker lines:
    [C,h]=contour3(X,Y,R,50);
    set(h,'LineWidth',3);
colormap(map1);
 





[J,K,L]=meshgrid(x); % 3D probability space
J=X;
K=Y;
L=1-J-K;            %change L to create plane for simplex

%set negative L to 0 for proper colors on contour, could alternatively set colors manually
    for j=1:length(x)
        for k=1:length(x)
            O(i,k)=0;   %blank       
            if L(j,k)< 0
               L(j,k)=NaN;
            end
        end
    end


s=surfc(J,K,L,O); 
figure; hold on; grid on
s=surfc(J,K,L,R); %inscribe contours in simplex
set(s,'FaceAlpha',1); 
colormap(map1); % keep colors consistent

%lets add moment constraints and associated errors
m1=2;         %mean of 3 sided dice = 2
m2=1.3;       %mean of 3 sided dice
m3=2.7;
%v1= 0.1 ;         % support size (minimum = 3*sd(means), vary with sample size)
%v2= 0.05 ;       % eg v1={-0.6,0,0.6} & v2={-0.3,0,0.3}


M1 = (m1-J-2*K)/3;           %define moments
M2 = (m2-J-2*K)/3;  
M3=(m3-J-2*K)/3;


    for j=1:length(x)           %limit constraint domain for visibility
        for k=1:length(x)
            if J(j,k)+K(j,k)>1.1
                    M1(j,k)=NaN;
                    M2(j,k)=NaN;
                    M3(j,k)=NaN;
            end
        end
    end


%VU1 = M1+v1 ;             %define error
%VL1 = M1-v1 ;               
%VU2 = M2+v2 ;
%VL2 = M2+v1 ;


m=surf(J,K,M1);              % plot moments
set(m,'FaceColor',[0.99 0.99 0.99],'FaceAlpha',0.6);%moment settings

n=surf(J,K,M2);             
set(n,'FaceColor',[0.99 0.99 0.99],'FaceAlpha',0.6);%moment settings

m3=surf(J,K,M3);             
set(m3,'FaceColor',[0.99 0.99 0.99],'FaceAlpha',0.4);%moment settings

%vu1 =surf(J,K,VU1);     %plot error bounds
%vl1 =surf(J,K,VL1);
%vu2 =surf(J,K,VU2);
%vl2 =surf(J,K,VU1);


%set(vu1,'FaceColor',[1 1 1],'FaceAlpha',1);%error settings
%set(vl1,'FaceColor',[0.6 0.6 0.6],'FaceAlpha',0.1);
%set(vu2,'FaceColor',[0.01 0.01 0.01],'FaceAlpha',0.1);
%set(vl2,'FaceColor',[0 0 0],'FaceAlpha',1);



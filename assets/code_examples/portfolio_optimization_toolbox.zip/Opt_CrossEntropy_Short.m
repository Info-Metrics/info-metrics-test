% this program solves for optimal portfolio at given risk aversion 

function [ret sig wgt] =  Opt_CrossEntropy_Short(Data,lambda,psi,varargin)
% Data: TxN
% lambda: risk aversion
% confidence: percentage

[T N] = size(Data);

AssetReturns = mean(Data)';
AssetCov = cov(Data);
nAsset = N;
options = optimoptions('fmincon','Display','none','Algorithm','sqp');

if isempty(varargin)
    q = ones(nAsset,1)/nAsset;
else
    q = varargin{:};
end

% find w using ME principal

z=[-1:0.2:1]; % discrete distribution of pi
M = length(z); % discretization of prior of original prior qi
W = zeros(M,nAsset);
for i = 1:length(q)
    funW = @(w) sum(w.*log(w));
    Aeq = [ones(1,M);z];
    beq = [1;q(i)];
    x0 = ones(M,1)/M;
    x = fmincon(funW,x0,[],[],Aeq,beq,[],[],[],options);
    W(:,i) = x;
end


%%

I = eye(nAsset);
Z = kron(I,z);

fun = @(p) sum(sum(reshape(p,M,nAsset).*log(reshape(p,M,nAsset)./W)));
x0 = W(:,1);
x0 = repmat(x0,nAsset,1);
Aeq = [kron(I,ones(1,M));
    ones(1,nAsset)*Z];
beq = [ones(nAsset,1);
    1];

mycon=@(wgt) deal(-(Z*wgt)'*AssetReturns + lambda.*(Z*wgt)'*AssetCov*(Z*wgt)./2 + psi,[]);

lb = -ones(size(x0));
ub = ones(size(x0));

x = fmincon(fun,x0,[],[],Aeq,beq,lb,ub,mycon,options);

ret = (Z*x)'*AssetReturns;
sig = sqrt((Z*x)'*AssetCov*(Z*x));
wgt = Z*x;
end

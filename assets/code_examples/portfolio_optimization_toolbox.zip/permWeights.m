function outMat =  permWeights(wgtVec,nAsset)
wgtVec = repmat(wgtVec,1,nAsset);

% in order to use allcom(a program to find combination of weights)
tmpStr = 'wgtVec(:,1)';
for i = 2:nAsset-1
    tmpStr = [tmpStr ',' 'wgtVec(:,' num2str(i) ')'];
end
outMat = eval(['allcomb(' tmpStr ')']);
ind = (sum(outMat,2)<1);
outMat = outMat(ind,:);
lastCol = 1 - sum(outMat,2);
outMat = [outMat lastCol];

end

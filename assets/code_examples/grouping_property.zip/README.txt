Installing Solver
Make sure you have the Solver Add-in installed, which can be found under the DATA tab in the toolbar.
If Solver is not installed, go to FILE --> Options.
On the right hand side panel,click on the Add-ins tab. At the bottom, click on the drop down menu next to Manage, and choose the Excel Add-ins option, and click Go.
In the new pop-up window, choose the Solver Add-in option and click ok.

Set up for the Question
Set up a 5x5 probability space where the values of the probabilities will be calculated in the optimization.
Enter values for our observed total of rows and columns (the information we have) which we will use as constraints for the optimization.
Based on the question, create excel formulae based on the constraints used for the question as a function of the cells where the probabilities will be calculated.
Also create formulae for the sum of each row and column as a function of the cells where the probabilities will be calculated.
Lastly, create an intermediary 5X5 table where the p*log(p) will be calculated for each probability as a function of the cells where the probabilities will be calculated. 
Create a cell with the entropy value, i.e. with formula that sums the values in the intermediary table created above. This will be the value/cell to be maximized.

Using the Solver
Select the cell where entropy value is calculated.
Go to DATA --> Solver.
For 'Set Obective' make sure the cell indicated is the one where entropy is calculated.
Select 'Max' in this case since we are maximizing entropy.
For 'By Changing Variable Cells', select all the cells in the original 5x5 space defined to calculate the probabilities.
To add constraints in the box, 'Subject to the Constraints', click add and enter the constraints according to the question.
For example, for the normalization constraints, for the left hand side, select the cells where the sum of the rows/columns are calculated. Choose the equal to sign in between, and on the right had side, enter 1. 
For the observed total value constraints, for the left hand side, select the cells where the constraint values as a function of the probabilities were defined previously. Set these equal to the observed total of the row/columns as per the question.

Check the box 'Make Unconstrained Values Non-Negative', since the probabilities need to be non-negative.
For 'Select a Solving Method', choose GRG Nonlinear.
Click Solve
Sometimes, the solver is sensitive to starting value for the probabilities to be calculated. Starting with the uniform distribution value of 0.04 for each probabilty, or something small and less that 1 like 0.1 can be helpful for the solver to converge to a solution.

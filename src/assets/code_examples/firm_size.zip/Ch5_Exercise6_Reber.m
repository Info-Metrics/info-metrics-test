clear;
clc;

%Distribution of Firm Size in Industry
%starting with simple case - example from book(1 input, 1 output)
K=10;
size = [1:K]';
rng('default');
sigma = [1;1;1;1;sqrt(2);sqrt(2);sqrt(2);sqrt(2);sqrt(3);sqrt(3)]; %generates error variances
    rng(111583); %seeds random number generator so results can be replicated
    error = randn(10,1).*sigma; %generates random error vector for production function

rng(012384);
x = randi(100,10,1);  %inputs for 10 firm types generated from U(1,100)
x = sort(x);

p_pop = [.032, .042, .065, .097, .133, .162, .201, .138, .094, .036]';  %true population distribution
beta = [.4, .4, .4, .4, .7, .7, .7, .7, 1.5, 1.5]';  %technology coefficient
a = 2;  %technology coefficient

%generating output according to production function
for i=1:K;
    b=beta(i,1);
    y(i,1)=CobbDouglas(a,b,x(i))+error(i,1);
end;

%calculating population means to be used as constraints
x_bar = p_pop'*x;
y_bar = p_pop'*y;

%Using fmincon and Entropy_firm_size function to estimate P using only
%input data and normalization
U=ones(K,1).*1/K;   %Initial guess for fmincon:  uniform distribution
Aeq=[x';ones(1,K)];  %equality constraints
beq=[x_bar;1];
lb=zeros(K,1);          %lower bound on probabilities = 0
ub=ones(K,1);           %upper bound on probabilities = 1
   opts = optimset('algorithm','sqp','TolFun',1e-15,'TolX',1e-15,'MaxFunEvals',1000000);
   [P,H,exitflag,output,lambda]=fmincon(@Entropy_firm_size, U, [], [], Aeq, beq, lb, ub,[],opts);
plot(size,P,size,p_pop,'DisplayName','P')
   xlabel('Firm Size (k = {1,2,...10})')
   ylabel('P(k)')
   title('ME Estimate for Size Distribution (inputs only)')
   legend('ME Estimate','Population Distribution',-1)
   
%Using fmincon and Entropy_firm_size function to estimate P using only
%output data and normalization
U=ones(K,1).*1/K;   %Initial guess for fmincon:  uniform distribution
Aeq=[y';ones(1,K)];  %equality constraints
beq=[y_bar;1];
lb=zeros(K,1);          %lower bound on probabilities = 0
ub=ones(K,1);           %upper bound on probabilities = 1
   opts = optimset('algorithm','sqp','TolFun',1e-15,'TolX',1e-15,'MaxFunEvals',1000000);
   [P,H,exitflag,output,lambda]=fmincon(@Entropy_firm_size, U, [], [], Aeq, beq, lb, ub,[],opts);
plot(size,P,size,p_pop,'DisplayName','P')
   xlabel('Firm Size (k = {1,2,...10})')
   ylabel('P(k)')
   title('ME Estimate for Size Distribution (outputs only)')
   legend('ME Estimate','Population Distribution',-1)
   
%Using fmincon and Entropy_firm_size function to estimate P using input and
%output data and normalization
U=ones(K,1).*1/K;   %Initial guess for fmincon:  uniform distribution
Aeq=[x';y';ones(1,K)];  %equality constraints
beq=[x_bar;y_bar;1];
lb=zeros(K,1);          %lower bound on probabilities = 0
ub=ones(K,1);           %upper bound on probabilities = 1
   opts = optimset('algorithm','sqp','TolFun',1e-15,'TolX',1e-15,'MaxFunEvals',1000000);
   [P,H,exitflag,output,lambda]=fmincon(@Entropy_firm_size, U, [], [], Aeq, beq, lb, ub,[],opts);
plot(size,P,size,p_pop,'DisplayName','P')
   xlabel('Firm Size (k = {1,2,...10})')
   ylabel('P(k)')
   title('ME Estimate for Size Distribution')
   legend('ME Estimate','Population Distribution',-1)

   
   
%Distribution of Firm Size in Industry
%expanding example from book (3 inputs, 1 output)
J=10;
size = [1:J]';
rng('default');
sigma = [1;1;1;1;sqrt(2);sqrt(2);sqrt(2);sqrt(2);sqrt(3);sqrt(3)]; %generates error variances
    rng(111583); %seeds random number generator so results can be replicated
    error = randn(10,1).*sigma; %generates random error vector for production function

A = [1;1;1;1;1.5;1.5;1.5;1.5;2;2];  %Technology inputs for 10 firm types 

rng(111583);
L = randi(100,10,1);  %input 2 for 10 firm types generated from U(1,100)
L = sort(L);

rng(012384);
K = randi(100,10,1);  %input 2 for 10 firm types generated from U(1,100)
K = sort(K);

p_pop = [.032, .042, .065, .097, .133, .162, .201, .138, .094, .036]';  %true population distribution
beta = [.4, .4, .4, .4, .7, .7, .7, .7, 1.5, 1.5]';  %technology coefficient
alpha = .5.*beta;  %technology coefficient

%generating output according to production function y=ax^b+e
for i=1:J;
    a=alpha(i,1);
    b=beta(i,1);
    y(i,1)=CobbDouglas_3(a,b,L(i),K(i),A(i))+error(i,1);
end;

%calculating population means to be used as constraints
L_bar = p_pop'*L;
K_bar = p_pop'*K;
A_bar = p_pop'*A;
y_bar = p_pop'*y;

U=ones(J,1).*1/J;   %Initial guess for fmincon:  uniform distribution
Aeq=[L';K';A';y';ones(1,J)];  %equality constraints
beq=[L_bar;K_bar;A_bar;y_bar;1];
lb=zeros(J,1);          %lower bound on probabilities = 0
ub=ones(J,1);           %upper bound on probabilities = 1
   opts = optimset('algorithm','sqp','TolFun',1e-15,'TolX',1e-15,'MaxFunEvals',1000000);
   [P,H,exitflag,output,lambda]=fmincon(@Entropy_firm_size, U, [], [], Aeq, beq, lb, ub,[],opts);
plot(size,P,size,p_pop,'DisplayName','P')
   xlabel('Firm Size (k = {1,2,...10})')
   ylabel('P(k)')
   title('ME Estimate for Size Distribution')
   legend('ME Estimate','Population Distribution',-1)
   
   
%Distribution of Firm Size in Industry
%expanding example from book to 4 inputs and 2 outputs
J=10;
size = [1:J]';
rng('default');
sigma = [1;1;1;1;sqrt(2);sqrt(2);sqrt(2);sqrt(2);sqrt(3);sqrt(3)]; %generates error variances
    rng(111583); %seeds random number generator so results can be replicated
error_y = randn(10,1).*sigma; %generates random error vector for production function
    
omega = [1;1;1;1;sqrt(2);sqrt(2);sqrt(2);sqrt(2);sqrt(3);sqrt(3)]; %generates error variances
    rng(012384); %seeds random number generator so results can be replicated
error_r = randn(10,1).*omega; %generates random error vector for production function

A = [1;1;1;1;1.5;1.5;1.5;1.5;2;2];  %Technology inputs for 10 firm types 
S = [20;20;20;20;15;15;15;15;12;12];  %Human capital inputs for 10 firm types

rng(111583);
L = randi(100,10,1);  %input 2 for 10 firm types generated from U(1,100)
L = sort(L);

rng(012384);
K = randi(100,10,1);  %input 2 for 10 firm types generated from U(1,100)
K = sort(K);

p_pop = [.032, .042, .065, .097, .133, .162, .201, .138, .094, .036]';  %true population distribution
beta = [.4, .4, .4, .4, .7, .7, .7, .7, 1.5, 1.5]';  %technology coefficient in FG production function
alpha = .5.*beta;  %technology coefficient in FG production function
delta = [5;5;5;5;3;3;3;3;2;2]; %technology coefficient in R&D production function

%generating output according to FG and R&D production functions
for i=1:J;
    a=alpha(i,1);
    b=beta(i,1);
    d=delta(i,1);
    Y(i,1)=CobbDouglas_Y(a,b,S(i),L(i),K(i),A(i))+error_y(i,1);
    R(i,1)=CobbDouglas_R(d,A(i),S(i))+error_r(i,1);
end;

%calculating population means to be used as constraints
S_bar = p_pop'*S;
L_bar = p_pop'*L;
K_bar = p_pop'*K;
A_bar = p_pop'*A;
y_bar = p_pop'*Y;
r_bar = p_pop'*R;

U=ones(J,1).*1/J;   %Initial guess for fmincon:  uniform distribution
Aeq=[S';L';K';A';Y';R';ones(1,J)];  %equality constraints
beq=[S_bar;L_bar;K_bar;A_bar;y_bar;r_bar;1];
lb=zeros(J,1);          %lower bound on probabilities = 0
ub=ones(J,1);           %upper bound on probabilities = 1
   opts = optimset('algorithm','sqp','TolFun',1e-15,'TolX',1e-15,'MaxFunEvals',1000000);
   [P,H,exitflag,output,lambda]=fmincon(@Entropy_firm_size, U, [], [], Aeq, beq, lb, ub,[],opts);
plot(size,P,size,p_pop,'DisplayName','P')
   xlabel('Firm Size (k = {1,2,...10})')
   ylabel('P(k)')
   title('ME Estimate for Size Distribution')
   legend('ME Estimate','Population Distribution',-1)
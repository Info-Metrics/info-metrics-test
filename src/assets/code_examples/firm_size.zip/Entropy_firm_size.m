%PURPOSE:  ME objective function for firm size example
function H = Entropy_firm_size(P) 

K=10;  %enter dimension of problem
for i = 1:K
   H(i) = (P(i)*log(P(i)));
end
H = sum(H);
return
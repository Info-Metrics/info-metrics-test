%PURPOSE:  Cobb Douglas production function for 3 input 1 output case

function y = CobbDouglas_3(a,b,L,K,A)

y  =  A*(L^b)*(K^a);

return
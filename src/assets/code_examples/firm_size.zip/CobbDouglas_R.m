%PURPOSE:  Cobb Douglas production for R&D in 4 input 2 output case

function R = CobbDouglas_R(d,S,A)

R  =  d*A*S;

return
%PURPOSE:  Cobb Douglas production for finished goods in 4 input 2 output case

function Y = CobbDouglas_Y(a,b,S,L,K,A)

Y  =  (A^(a+b))*(S^a)*(L^b)*(K^(1-a-b));

return
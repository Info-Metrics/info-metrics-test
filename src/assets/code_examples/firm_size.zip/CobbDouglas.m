%PURPOSE: Calculates Cobb Douglas output for 1 input 1 output case
function y = CobbDouglas(a,b,x)

y  =  a*x^b;

return
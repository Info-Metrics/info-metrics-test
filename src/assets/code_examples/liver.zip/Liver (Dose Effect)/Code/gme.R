gmereglin.obj<-function(lambda,y,x,z,v){
  # INPUTS:
  #    lambda - lagrange multipliers of the dual (nx1 vector)
  #    y  - dependent variable (nx1 vector)
  #    x  - independent variables (nxk matrix)
  #    z  - support for beta coefs (kxm matrix)
  #    v  - support for error terms (mx1 vector det'd by the 3-sigma rule)
  # OUTPUT:
  #    ll - concentrated likelihood (dual)
  # Dimensions
  dimX<-dim(x)
  n<-dimX[1]   # Number of observations
  k<-dimX[2]   # Number of regressor (incl. constant)
  M<-dim(z)[2]
  # Partition function (Phi)
  Phi<-matrix(0,k,1)
  for (j in 1:k) {
    for (m in 1:M) {
      Phi[j,1]<-Phi[j,1]+exp(-z[j,m]*sum(lambda*x[,j]))
    }
  }
  # Partition function (Psi)
  Psi<-matrix(0,n,1)
  for (i in 1:n){
    Psi[i,1]<-sum(exp(-lambda[i]*v))
  }
  # Dual (Concentrated log-likelihood)
  ll<-sum(y*lambda)+sum(log(Phi))+sum(log(Psi))
  # Return value
  return(ll)
}

gmereglin.Gr<-function(lambda,y,x,z,v){
  # INPUTS:
  #    lambda - lagrange multipliers of the dual (nx1 vector)
  #    y  - dependent variable (nx1 vector)
  #    x  - independent variables (nxk matrix)
  #    z  - support for beta coefs (kxm matrix)
  #    v  - support for error terms (mx1 vector det'd by the 3-sigma rule)
  # OUTPUT:
  #    ll - concentrated likelihood (dual)
  # Dimensions
  dimX<-dim(x)
  n<-dimX[1]   # Number of observations
  K<-dimX[2]   # Number of regressor (incl. constant)
  M<-dim(z)[2]
  # Partition function (Phi)
  Phi<-matrix(0,K,1)
  for (k in 1:K) {
    for (m in 1:M) {
      Phi[k,1]<-Phi[k,1]+exp(-z[k,m]*sum(lambda*x[,k]))
    }
  }
  # Partition function (Psi)
  Psi<-matrix(0,n,1)
  for (i in 1:n){
    Psi[i,1]<-sum(exp(-lambda[i]*v))
  }
  # First-order derivative of Partition function (Phi)
  grad<-matrix(0,n,1)
  Phi1<-matrix(0,K,1)
  Psi1<-matrix(0,n,1)
  for (i in 1:n) {
    temp<-0
    for (k in 1:K) {
      for (m in 1:M) {
        Phi1[k,1]<-Phi1[k,1]+z[k,m]*exp(-z[k,m]*sum(lambda*x[,k]))
      }
      temp<-temp-x[i,k]*Phi1[k,1]/Phi[k,1]
    }
    Psi1[i,1]<- -sum(v*exp(-lambda[i]*v))
    grad[i,1]<- y[i]+temp+Psi1[i,1]/Psi[i,1] 
  }
  # Return value
  return(grad)
}

gmereglin.est<-function(y,x,z,optim_Method) {
  # Dimensions
  dimX<-dim(x)
  n<-dimX[1]   # Number of observations
  k<-dimX[2]   # Number of regressor (incl. constant)
  M<-dim(z)[2]
  # Error support by the 3 sigma rule
  sdY<-sd(y)
  v=matrix(0,3,1)
  v[1,1]<- -3*sdY
  v[3,1]<-  3*sdY
  # Initial values of lagrange multipliers
  lambda0<-matrix(0,n,1)
  # Optimization
  gme.est<-optim(lambda0,gmereglin.obj,gmereglin.Gr,y=y,x=x,z=z,v=v,method=optim_Method)
  # Lagrange multipliers
  lambda.hat<-gme.est$par
  # Est'd prob's for the beta coefficients
  p.hat<-matrix(0,k,M)
  for (j in 1:k) {
    for (m in 1:M) {
      p.hat[j,m]<-exp(-z[j,m]*sum(lambda.hat*x[,j]))
    }
    p.hat[j,]<-p.hat[j,]/sum(p.hat[j,])
  }
  # Beta coef's
  beta.hat<-matrix(0,k,1)
  for (j in 1:k) {
    beta.hat[j,1]<-sum(z[j,]*p.hat[j,])
  }
  # Est'd prob's for the noise 
  w.hat<-matrix(0,n,3)
  for (i in 1:n) {
    for (m in 1:3) {
      w.hat[i,m]<-exp(-lambda.hat[i,1]*v[m,1])
    }
    w.hat[i,]<-w.hat[i,]/sum(w.hat[i,])
  }
  # Error terms
  e.hat<-matrix(0,n,1)
  for (i in 1:n) {
    e.hat[i,1]<-w.hat[i,]%*%v[,1]
  }
  # return value
  newList<-list("lambda"=lambda.hat,"beta"=beta.hat,"p"=p.hat,"w"=w.hat,"e"=e.hat,"conv"=gme.est$conv)
  return(newList)
}
